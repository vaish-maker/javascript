# Javascipt-operator-
here i mentioned all the operator which can be perform on the console!
